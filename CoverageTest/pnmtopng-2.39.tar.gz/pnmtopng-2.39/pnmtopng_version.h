#define VERSION "2.39 (12 November 2005)"
